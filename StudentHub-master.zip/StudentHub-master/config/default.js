//MongoAtlas access URI

module.exports = {
  mongoURI:
    "mongodb+srv://kohliharsh:W@terl0705@cluster0.nzdyb.mongodb.net/test?retryWrites=true&w=majority",
  jwtSecret: "secret",
};
